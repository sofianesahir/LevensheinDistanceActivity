﻿using System.Activities.Presentation.Metadata;
using System.ComponentModel;
using System.ComponentModel.Design;
using UiPathTeam.String.Utilities.Activities.Activities;
using UiPathTeam.String.Utilities.Activities.Design.Designers;
using UiPathTeam.String.Utilities.Activities.Design.Properties;

namespace UiPathTeam.String.Utilities.Activities.Design
{
    public class DesignerMetadata : IRegisterMetadata
    {
        public void Register()
        {
            var builder = new AttributeTableBuilder();
            builder.ValidateTable();

            var categoryAttribute =  new CategoryAttribute($"{Resources.Category}");

            builder.AddCustomAttributes(typeof(LevenshteinDistance), new DesignerAttribute(typeof(LevenshteinDistanceDesigner)));
            builder.AddCustomAttributes(typeof(DamerauLevenshteinDistance), new DesignerAttribute(typeof(DamerauLevenshteinDistanceDesigner)));

            MetadataStore.AddAttributeTable(builder.CreateTable());
        }
    }
}
