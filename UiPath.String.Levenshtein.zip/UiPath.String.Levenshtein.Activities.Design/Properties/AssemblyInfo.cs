﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("UiPathTeam.String.Utilities.Activities")]
[assembly: AssemblyDescription("Levenshtein distance algorithm. Based on 2 input sequences, the algorithm checks the similarity between both sequences. If 2 sequences are identical the algorithm return 0 else it returns a number > 0.")]

// Setting ComVisible to false makes the types in this assembly not visible
// to COM components.  If you need to access a type in this assembly from
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("4D542905-E7F0-4C23-B1D5-079630314E92")]
