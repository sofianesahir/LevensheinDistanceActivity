﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UiPathTeam.String.Utilities.Activities.Activities
{
    class Levenshtein
    {
        protected string First { get; set; }
        protected string Second { get; set; }

        public Levenshtein()
        {
            this.First = "";
            this.Second = "";
        }

        public Levenshtein(string first, string second)
        {
            this.First = first;
            this.Second = second;
        }

        public static int LevenshteinDistance(string first, string second)
        {
            int firstSeqLen = first.Length;
            int secondSeqLen = second.Length;

            int cost;

            int[,] d = new int[firstSeqLen + 1, secondSeqLen + 1];

            if (firstSeqLen == 0)
            {
                return secondSeqLen;
            }

            if (secondSeqLen == 0)
            {
                return firstSeqLen;
            }

            for (int i = 0; i <= firstSeqLen; i++)
            {
                d[i, 0] = i;
            }

            for (int j = 0; j <= secondSeqLen; j++)
            {
                d[0, j] = j;
            }

            for (int i = 1; i <= firstSeqLen; i++)
            {
                for (int j = 1; j <= secondSeqLen; j++)
                {
                    if (second[j - 1] == first[i - 1])
                        cost = 0;
                    else
                        cost = 1;
                    d[i, j] = Math.Min(Math.Min(d[i - 1, j] + 1, d[i, j - 1] + 1), d[i - 1, j - 1] + cost);
                }
            }

            return d[firstSeqLen, secondSeqLen];
        }

        public static int DamerauLevenshteinDistance(string first, string second)
        {
            int firstSeqLen = first.Length;
            int secondSeqLen = second.Length;

            int cost;

            int[,] d = new int[firstSeqLen + 1, secondSeqLen + 1];

            if (firstSeqLen == 0)
            {
                return secondSeqLen;
            }

            if (secondSeqLen == 0)
            {
                return firstSeqLen;
            }

            for (int i = 0; i <= firstSeqLen; i++)
            {
                d[i, 0] = i;
            }

            for (int j = 0; j <= secondSeqLen; j++)
            {
                d[0, j] = j;
            }

            for (int i = 1; i <= firstSeqLen; i++)
            {
                for (int j = 1; j <= secondSeqLen; j++)
                {
                    if (second[j - 1] == first[i - 1])
                        cost = 0;
                    else
                        cost = 1;

                    d[i, j] = Math.Min(Math.Min(d[i - 1, j] + 1, d[i, j - 1] + 1), d[i - 1, j - 1] + cost);

                    if (i > 1 && j > 1 && first[i] == second[j - 1] && first[i - 1] == second[j])
                        d[i, j] = Math.Min(d[i, j],
                                            d[i - 2, j - 2] + cost); 
                }
            }

            return d[firstSeqLen, secondSeqLen];
        }

    }
}
