﻿using System.Collections.Generic;
using System.Activities;
using System.ComponentModel;
using System.Activities.Validation;

namespace UiPathTeam.String.Utilities.Activities.Activities
{
    public class DamerauLevenshteinTable : CodeActivity
    {
        [Category("Input")]
        public InArgument<string> Word { get; set; }

        [Category("Input")]
        public InArgument<string[]> Referential { get; set; }

        [Category("Output")]
        public OutArgument<Dictionary<string, int>> Result { get; set; }

        protected override void CacheMetadata(CodeActivityMetadata metadata)
        {
            base.CacheMetadata(metadata);

            if (Word == null)
            {
                ValidationError error = new ValidationError("Word is empty.", false);
                metadata.AddValidationError(error);
            }

            if (Referential == null)
            {
                ValidationError error = new ValidationError("Referential is empty.", false);
                metadata.AddValidationError(error);
            }
        }

        protected override void Execute(CodeActivityContext context)
        {
            string[] wordList = Referential.Get(context);
            string w = Word.Get(context);
            var dictionary = new Dictionary<string, int>();


            foreach (string item in wordList)
            {
                dictionary.Add(item, Levenshtein.DamerauLevenshteinDistance(w, item));
            }

            Result.Set(context, dictionary);
        }
    }
}
