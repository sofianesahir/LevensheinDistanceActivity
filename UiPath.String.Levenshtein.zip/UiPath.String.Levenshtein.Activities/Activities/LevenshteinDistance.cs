﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Activities;
using System.ComponentModel;
using UiPathTeam.String.Utilities.Activities.Properties;

namespace UiPathTeam.String.Utilities.Activities.Activities
{
    public class LevenshteinDistance : CodeActivity
    {
        [LocalizedDisplayName(nameof(Resources.FirstSequenceDisplayName))]
        [LocalizedDescription(nameof(Resources.FirstSequenceDescription))]
        [LocalizedCategory(nameof(Resources.Input))]
        public InArgument<string> FirstSequence { get; set; }

        [LocalizedDisplayName(nameof(Resources.SecondSequenceDisplayName))]
        [LocalizedDescription(nameof(Resources.SecondSequenceDescription))]
        [LocalizedCategory(nameof(Resources.Input))]
        public InArgument<string> SecondSequence { get; set; }

        [LocalizedDisplayName(nameof(Resources.DistanceDisplayName))]
        [LocalizedDescription(nameof(Resources.DistanceDescription))]
        [LocalizedCategory(nameof(Resources.Output))]
        public OutArgument<int> Distance { get; set; }

       

        protected override void Execute(CodeActivityContext context)
        {
            string firstSequence = FirstSequence.Get(context);
            string secondSequence = SecondSequence.Get(context);

            Distance.Set(context,Levenshtein.LevenshteinDistance(firstSequence, secondSequence));
        }
    }
}
