﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("UiPathTeam.String.Utilities.Activities")]
[assembly: AssemblyDescription("Levenshtein distance algorithm. BAse on 2 input sequences, the algorithm check the similarity between both sequences. if 2 sequences are identical the algorithm return 0 else it returns a number > 0.")]

// Setting ComVisible to false makes the types in this assembly not visible
// to COM components.  If you need to access a type in this assembly from
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("EB8EF423-4EA9-4F8B-8976-D1EBB4BD5FD8")]
